/*===========================================
        GRRLIB (GX Version)
        - Template Code -

        Minimum Code To Use GRRLIB
============================================*/
#include <grrlib.h>
#include <ogc/lwp_watchdog.h>   // Needed for gettime and ticks_to_millisecs
#include <asndlib.h>
#include <stdlib.h>
#include <stdio.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <gcmodplay.h>
#include "oggplayer.h"

//#include "font_png.h"
#include "font2_png.h"
//#include "font3_ttf.h"
#include "BMfont5_png.h"
#include "anxiety_ogg.h"
#include "jazzgrade_ogg.h"
#include "amazonianDyslexia_ogg.h"
#include "maze_png.h"

#define rightheld() (WPAD_ButtonsHeld(0) & WPAD_BUTTON_RIGHT)
#define leftheld() (WPAD_ButtonsHeld(0) & WPAD_BUTTON_LEFT)
#define upheld() (WPAD_ButtonsHeld(0) & WPAD_BUTTON_UP)
#define downheld() (WPAD_ButtonsHeld(0) & WPAD_BUTTON_DOWN)
#define classicrightheld() (WPAD_ButtonsHeld(0) & WPAD_CLASSIC_BUTTON_RIGHT)
#define classicleftheld() (WPAD_ButtonsHeld(0) & WPAD_CLASSIC_BUTTON_LEFT)
#define classicupheld() (WPAD_ButtonsHeld(0) & WPAD_CLASSIC_BUTTON_UP)
#define classicdownheld() (WPAD_ButtonsHeld(0) & WPAD_CLASSIC_BUTTON_DOWN)

#define plusdown() (WPAD_ButtonsDown(0) & WPAD_BUTTON_PLUS) || (WPAD_ButtonsDown(0) & WPAD_CLASSIC_BUTTON_PLUS)
#define minusdown() (WPAD_ButtonsDown(0) & WPAD_BUTTON_MINUS) || (WPAD_ButtonsDown(0) & WPAD_CLASSIC_BUTTON_MINUS)
#define homedown() (WPAD_ButtonsDown(0) & WPAD_BUTTON_HOME) || (WPAD_ButtonsDown(0) & WPAD_CLASSIC_BUTTON_HOME)

#define GRRLIB_BLACK   0x000000FF
#define GRRLIB_MAROON  0x800000FF
#define GRRLIB_GREEN   0x008000FF
#define GRRLIB_OLIVE   0x808000FF
#define GRRLIB_NAVY    0x000080FF
#define GRRLIB_PURPLE  0x800080FF
#define GRRLIB_TEAL    0x008080FF
#define GRRLIB_CYAN    0x00FFFFFF
#define GRRLIB_GRAY    0x808080FF
#define GRRLIB_SILVER  0xC0C0C0FF
#define GRRLIB_RED     0xFF0000FF
#define GRRLIB_LIME    0x00FF00FF
#define GRRLIB_YELLOW  0xFFFF00FF
#define GRRLIB_BLUE    0x0000FFFF
#define GRRLIB_FUCHSIA 0xFF00FFFF
#define GRRLIB_AQUA    0x00FFFFFF
#define GRRLIB_WHITE   0xFFFFFFFF

//static MODPlay play;

int main(int argc, char **argv) {
    // Initialise the Graphics & Video subsystem
    GRRLIB_Init();

    // Initialise the Wiimotes
    WPAD_Init();
    WPAD_SetDataFormat(WPAD_CHAN_0, WPAD_FMT_BTNS_ACC_IR); // allows usage of buttons, accelerometer, and ir sensor (a.k.a the thing that makes your wiimote go pointy point)

    // Initialise the audio subsystem
	ASND_Init();

    //GRRLIB_texImg *font = GRRLIB_LoadTexture(font_png);
    //GRRLIB_InitTileSet(font, 4, 6, 33);
    GRRLIB_texImg *font2 = GRRLIB_LoadTexture(font2_png);
    GRRLIB_InitTileSet(font2, 4, 6, 33);
    //GRRLIB_ttfFont *font3 = GRRLIB_LoadTTF(font3_ttf, font3_ttf_size);
    GRRLIB_texImg *tex_BMfont5 = GRRLIB_LoadTexture(BMfont5_png);
    GRRLIB_InitTileSet(tex_BMfont5, 8, 16, 0);

    float x = 5;
    float y = 5;
    float ang0 = 0;
    float mag0 = 0;
    float ang1 = 0;
    float mag1 = 0;
	int song = 0;
	int gamestate = 0;
	const int GAMESTATES_MENU = 0;
	const int GAMESTATES_CONTROLS = 1;
	const int GAMESTATES_CREDITS = 2;
	const int GAMESTATES_GAME = 3;
	const int GAMESTATES_WIN = 4;
	const int GAMESTATES_LOSE = 5;
	
	int rumbleclock = 5;

    float rad(float deg) {
        return deg * 0.01745329;
    }

	struct expansion_t othercontroller; //nunchuk or classic controller
	struct ir_t irsensor;

	PlayOgg(anxiety_ogg, anxiety_ogg_size, 0, OGG_INFINITE_TIME);

    // Loop forever
    while(1) {
	WPAD_SetVRes(0, 640, 480);
        WPAD_ScanPads();  // Scan the Wiimotes
        WPAD_Expansion(0,&othercontroller); // check if there's a controller connected to the wiimote
	WPAD_IR(0, &irsensor); // check the ir sensor

	switch (gamestate) {
		case GAMESTATES_MENU:
			
		case GAMESTATES_CONTROLS:
			
		case GAMESTATES_CREDITS:
			
		case GAMESTATES_GAME:
			
		case GAMESTATES_WIN:
			
		case GAMESTATES_LOSE:
			
	}

        // check if there's a nunchuck or classic controller connected
        if (othercontroller.type == WPAD_EXP_NUNCHUK) {
            ang0 = othercontroller.nunchuk.js.ang;
            mag0 = othercontroller.nunchuk.js.mag;
            x += sin(rad(ang0)) * mag0;
            y -= cos(rad(ang0)) * mag0;
        }
        else {
            if (othercontroller.type == WPAD_EXP_CLASSIC) {
                ang0 = othercontroller.classic.ljs.ang;
                mag0 = othercontroller.classic.ljs.mag;
                ang1 = othercontroller.classic.rjs.ang;
                mag1 = othercontroller.classic.rjs.mag;
                x += sin(rad(ang0)) * mag0;
                y -= cos(rad(ang0)) * mag0;
                x += classicrightheld() ? 1 : (classicleftheld() ? -1 : 0);
                y -= classicupheld() ? 1 : (classicdownheld() ? -1 : 0);
            }
        }
        // this game is meant to be played sideways
        x += downheld() ? 1 : (upheld() ? -1 : 0);
        y += leftheld() ? 1 : (rightheld() ? -1 : 0);
        
	if (rumbleclock < 5) {
		
	}
	
	if (plusdown()) {
		song++;
		if (song > 2) song = 0;
		StopOgg();
		if (song == 0) PlayOgg(anxiety_ogg, anxiety_ogg_size, 0, OGG_INFINITE_TIME);
		if (song == 1) PlayOgg(jazzgrade_ogg, jazzgrade_ogg_size, 0, OGG_INFINITE_TIME);
		if (song == 2) PlayOgg(amazonianDyslexia_ogg, amazonianDyslexia_ogg_size, 0, OGG_INFINITE_TIME);
	}

	if (minusdown()) {
		song--;
		if (song > 2) song = 0;
		StopOgg();
		if (song == 0) PlayOgg(anxiety_ogg, anxiety_ogg_size, 0, OGG_INFINITE_TIME);
		if (song == 1) PlayOgg(jazzgrade_ogg, jazzgrade_ogg_size, 0, OGG_INFINITE_TIME);
		if (song == 2) PlayOgg(amazonianDyslexia_ogg, amazonianDyslexia_ogg_size, 0, OGG_INFINITE_TIME);
	}

        // If [HOME] was pressed on the first Wiimote, break out of the loop
        if homedown()  break;

        // ---------------------------------------------------------------------
        // Place your drawing code here 
        GRRLIB_FillScreen(GRRLIB_BLACK);    // Clear the screen
        GRRLIB_Printf(100, 25, tex_BMfont5, GRRLIB_GREEN, 1, "x: %f Y: %f", x, y);
        //GRRLIB_Printf(100, 50, font, GRRLIB_TEAL, 2, " !\"#$&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
        //GRRLIB_PrintfTTF(100, 75, font3, "please just work", 16, GRRLIB_TEAL);
        GRRLIB_Printf(100, 100, tex_BMfont5, GRRLIB_TEAL, 1, "ANG0: %f MAG0: %f", ang0, mag0);
        GRRLIB_Printf(100, 125, tex_BMfont5, GRRLIB_TEAL, 1, "ANG1: %f MAG1: %f", ang1, mag1);
        GRRLIB_Rectangle(x,y,10,10,GRRLIB_CYAN,1);

        // ---------------------------------------------------------------------

        GRRLIB_Render();  // Render the frame buffer to the TV
    }
    //GRRLIB_FreeTexture(font);
    GRRLIB_FreeTexture(font2);
    //GRRLIB_FreeTTF(font3);
    GRRLIB_FreeTexture(tex_BMfont5);
    GRRLIB_Exit(); // Be a good boy, clear the memory allocated by GRRLIB

	StopOgg();
    exit(0);  // Use exit() to exit a program, do not use 'return' from main()
}
